function imprimirNoTerminal() {
  console.log("Conexão feita com sucesso!");
}

imprimirNoTerminal();
imprimirNoTerminal();
imprimirNoTerminal();